' Stop the workbench services only. ASCII-only body (see start launcher).
Option Explicit
Dim sh, fso, folder, root, pyw, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = ChrW(&H4F17) & ChrW(&H5E55) & "AI" & ChrW(&H5DE5) & ChrW(&H4F5C) & ChrW(&H53F0)
root = "C:\Users\52436\Desktop\" & folder & "\app"
pyw = root & "\.venv\Scripts\pythonw.exe"
If Not fso.FileExists(pyw) Then pyw = "pythonw.exe"
sh.CurrentDirectory = root
cmd = """" & pyw & """ """ & root & "\desktop\stop.py"""
sh.Run cmd, 0, False
