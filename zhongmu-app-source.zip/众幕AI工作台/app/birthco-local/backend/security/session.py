"""Opaque local sessions and request-bound CSRF tokens."""
import base64
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import re
import secrets

from flask import Blueprint, current_app, g, request

from backend.domain.errors import DomainError
from backend.storage.db import connect, immediate

blueprint = Blueprint("session", __name__)
COOKIE = "birthco_session"
KEY_PATTERN = re.compile(r"^[\x20-\x7e]{16,128}$")


def _digest(value: str) -> str:
    return hmac.new(current_app.config["SESSION_SECRET"], value.encode(), hashlib.sha256).hexdigest()


def _csrf_token(session_id: str) -> str:
    """会话绑定的确定性 CSRF token：同会话恒等，bootstrap 可重复调用（幂等）。

    替代此前每次 bootstrap 生成随机 token 的做法——多份前端会话缓存
    （工作台与账号组件各自 ensureSession）重复 bootstrap 会互相顶掉对方
    的 token，写请求随之报 "CSRF token invalid"。服务端仍只存 digest。
    """
    mac = hmac.new(current_app.config["SESSION_SECRET"],
                   b"csrf:" + session_id.encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(mac).rstrip(b"=").decode("ascii")


def _allowed_origins() -> set[str]:
    configured = current_app.config.get("ALLOWED_ORIGINS")
    if configured:
        return set(configured)
    host = current_app.config.get("BIND_HOST", "127.0.0.1")
    port = current_app.config.get("BIND_PORT", 5000)
    return {f"http://{host}:{port}"}


def _loopback(value: str) -> bool:
    """Whether a host / origin points at this machine (any local port).

    The service binds 127.0.0.1 only, so accepting the localhost alias and any
    loopback port cannot expose it beyond the machine. This keeps the workbench
    usable from a desktop app window, a Vite proxy and a direct API base URL
    alike, instead of rejecting them as ORIGIN_DENIED.
    """
    host = value.split("://", 1)[-1].split("/", 1)[0]
    if host.startswith("["):
        host = host[1:].split("]", 1)[0]
    else:
        host = host.rsplit(":", 1)[0] if ":" in host else host
    return host.lower() in {"127.0.0.1", "localhost", "::1"}


def validate_origin() -> None:
    origins = _allowed_origins()
    # Host must be the exact configured loopback address (a Host header pointing
    # at another alias is still refused). Origin/Referer may use any loopback
    # port so a Vite proxy, a desktop app window or a direct API base all work.
    allowed_hosts = {origin.split("://", 1)[-1] for origin in origins}
    if request.host not in allowed_hosts:
        raise DomainError("ORIGIN_DENIED", "Unexpected local host", "Open the local workbench address")
    origin = request.headers.get("Origin")
    if origin and origin not in origins and not _loopback(origin):
        raise DomainError("ORIGIN_DENIED", "Cross-origin request", "Use the local workbench")
    site = request.headers.get("Sec-Fetch-Site")
    if site and site != "same-origin":
        raise DomainError("ORIGIN_DENIED", "Cross-site request", "Use the local workbench")
    referer = request.headers.get("Referer")
    if referer and not any(referer.startswith(item + "/") for item in origins) and not _loopback(referer):
        raise DomainError("ORIGIN_DENIED", "Cross-origin referrer", "Use the local workbench")


def require_session():
    cookie = request.cookies.get(COOKIE)
    if not cookie:
        raise DomainError("SESSION_REQUIRED", "本地会话缺失，请刷新工作台",
                          "重新打开或刷新页面以建立会话", retryable=True)
    with connect(current_app.config["DB_PATH"]) as db:
        row = db.execute("SELECT id,csrf_hash,capability,expires_at FROM app_sessions WHERE id=?", (_digest(cookie),)).fetchone()
        now = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        if row is None or row["expires_at"] <= now:
            raise DomainError("SESSION_REQUIRED", "本地会话已过期，请重新连接后端",
                              "刷新页面，前端会自动重新建立会话", retryable=True)
        g.local_session = dict(row)
        return g.local_session


def require_write():
    session = require_session()
    csrf = request.headers.get("X-CSRF-Token", "")
    if not csrf or not hmac.compare_digest(_digest(csrf), session["csrf_hash"]):
        raise DomainError("SESSION_REQUIRED", "CSRF 校验失败，请刷新页面后重试",
                          "刷新工作台以重新取回会话凭据", retryable=True)
    key = request.headers.get("Idempotency-Key", "")
    if not KEY_PATTERN.fullmatch(key):
        raise DomainError("SCHEMA_INVALID", "Idempotency key must be 16-128 printable ASCII characters", "Provide a new request key")
    return session, key


@blueprint.get("/api/v1/session")
def bootstrap():
    from backend.api import success
    cookie = request.cookies.get(COOKIE)
    session_id = _digest(cookie) if cookie else None
    new_cookie = cookie or secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expiry = (now + timedelta(hours=12)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    with connect(current_app.config["DB_PATH"]) as db:
        with immediate(db):
            existing = db.execute("SELECT id,expires_at FROM app_sessions WHERE id=?", (session_id,)).fetchone() if session_id else None
            if existing and existing["expires_at"] > now.isoformat(timespec="milliseconds").replace("+00:00", "Z"):
                pass  # 复用会话；CSRF 为派生值，重复 bootstrap 不轮换
            else:
                new_cookie = secrets.token_urlsafe(32)
                session_id = _digest(new_cookie)
                db.execute("INSERT INTO app_sessions(id,csrf_hash,capability,expires_at) VALUES(?,?,'creator',?)", (session_id, "", expiry))
            csrf = _csrf_token(session_id)
            db.execute("UPDATE app_sessions SET csrf_hash=?,expires_at=? WHERE id=?", (_digest(csrf), expiry, session_id))
    response = success({"session_id": session_id, "csrf_token": csrf, "capabilities": ["creator"]})
    response.set_cookie(COOKIE, new_cookie, httponly=True, samesite="Strict", secure=False, path="/", max_age=12 * 3600)
    return response
