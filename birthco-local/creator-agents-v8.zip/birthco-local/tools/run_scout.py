"""Run a single materials-only Scout operation; Mock by default."""
import argparse
import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.agents.scout import ScoutAgent,ScoutInput
from backend.domain.errors import DomainError


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--live",action="store_true",help="Use Qwen for one billable analysis call; does not enable web search")
    args=parser.parse_args()
    if args.input.stat().st_size>1048576:parser.error("input exceeds 1 MiB")
    snapshot=ScoutInput.model_validate_json(args.input.read_text(encoding="utf-8"))
    if args.live:
        from backend.adapters.model.qwen import QwenAdapter
        with QwenAdapter() as adapter:
            result=ScoutAgent(adapter,mode="live",model_id=os.environ.get("QWEN_MODEL_ID")).run(snapshot)
    else:result=ScoutAgent().run(snapshot)
    text=json.dumps(result.as_dict(),ensure_ascii=False,indent=2)+"\n"
    if args.output:args.output.write_text(text,encoding="utf-8")
    else:print(text)


if __name__=="__main__":
    try:main()
    except DomainError as exc:
        print(json.dumps({"error":exc.detail().model_dump()},ensure_ascii=False),file=sys.stderr);raise SystemExit(1)
    except (ValueError,KeyError,OSError):
        print("Input or model configuration is invalid. Check the local Scout example.",file=sys.stderr);raise SystemExit(2)
